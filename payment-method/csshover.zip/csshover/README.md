# CSS - 特別的 Hover 效果

A Pen created on CodePen.

Original URL: [https://codepen.io/RayPan/pen/PobZQQy](https://codepen.io/RayPan/pen/PobZQQy).

參考網站： https://kenchiku-cg.com/service#Concept